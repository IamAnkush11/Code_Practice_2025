// getting reusability of Info interface in TeacherInfo
var teacher = {
    name: "John",
    age: 30,
    subject: "Math"
};
