function LoginInfo() {
    const username = document.getElementById('username') as HTMLInputElement;
    const password = document.getElementById('password') as HTMLInputElement;
    const loginMsg = document.querySelector('h1') as HTMLElement | null;

    if (username.value && password.value) {
        console.log(`Username: ${username.value}, Password: ${password.value}`);
        // Here you can add further logic to handle the login process
       if (loginMsg) {
            loginMsg.textContent = `Welcome, ${username.value}!`;
        }

    } else {
        console.error('Username and password cannot be empty');
    }
}