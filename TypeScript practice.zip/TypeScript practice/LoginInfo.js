function LoginInfo() {
    var username = document.getElementById('username');
    var password = document.getElementById('password');
    var loginMsg = document.querySelector('h1');
    if (username.value && password.value) {
        console.log("Username: ".concat(username.value, ", Password: ").concat(password.value));
        // Here you can add further logic to handle the login process
        if (loginMsg) {
            loginMsg.textContent = "Welcome, ".concat(username.value, "!");
        }
    }
    else {
        console.error('Username and password cannot be empty');
    }
}
