// Class Decorator
function classLogger(constructor: Function) {
  console.log(`Class created with name: ${constructor.name}`);
}

// Property Decorator
function getValue(target: any, key: string) {
  console.log(`Property found: ${key}`);
}

@classLogger
class UserService {
  @getValue
  num: number;

  constructor(x: number) {
    this.num = x;
  }
}

let user1 = new UserService(11);
console.log(user1.num); // Output: 11
