interface Info {
  name: string; 
  age: number;
}

interface TecherInfo extends Info{
  subject: string;
} 


// getting reusability of Info interface in TeacherInfo

var teacher: TecherInfo = {
    name: "John",
    age: 30,        
    subject: "Math"
}